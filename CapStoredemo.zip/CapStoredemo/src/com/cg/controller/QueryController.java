package com.cg.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	

	@RequestMapping("/index")
	public String index() {
		
		return "index";
	}
	
	@RequestMapping("/pwencript")
	public String pwencript(Model model,@RequestParam("password") String password) {
		String pass=iQueryService.passwordEncrypt(password);
		return "pwencript";
	}
	
	
}
