package com.cg.dao;



public interface IQueryDAO {
	

	public String passwordEncrypt(String password);
	
}
