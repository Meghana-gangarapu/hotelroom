package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;


@Repository
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	String s2="abc";

	@Override
	public String passwordEncrypt(String password) {
		String password1 = password.concat(s2);
	     //entityManager.persist(password1);
		int customerId=1;
		Customer cust=entityManager.find(Customer.class,customerId);
	   System.out.println( password1);
		return password1;
	}






	
	
}
