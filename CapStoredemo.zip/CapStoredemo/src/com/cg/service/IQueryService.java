package com.cg.service;





public interface IQueryService {



public String passwordEncrypt(String password);

}
