package com.cg.registrationmanagementsystem.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationBean {

	@FindBy(how=How.XPATH,xpath="//*[@id=\"usrID\"]")
	WebElement userId;
	
	@FindBy(how=How.NAME,name="passid")
	WebElement password;
	
	@FindBy(how=How.ID,id="usrname")
	WebElement name;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"addr\"]")
	WebElement address;
	
	@FindBy(how=How.NAME,name="country")
	WebElement country;
	
	@FindBy(how=How.NAME,name="zip")
	WebElement zipCode;
	
	@FindBy(how=How.NAME,name="email")
	WebElement email;
	
	@FindBy(how=How.NAME,name="sex")
	List<WebElement> sex;
	
	@FindBy(how=How.NAME,name="language")
	List<WebElement> language;
	
	@FindBy(how=How.NAME,name="submit")
	WebElement submitButton;
	
	
public void clickButton() {		
	submitButton.click();
	}


public void setUserId(String userId) {
	this.userId.sendKeys(userId);
}


public void setPassword(String password) {
	this.password.sendKeys(password);
}


public void setName(String name) {
	this.name.sendKeys(name);
}


public void setAddress(String address) {
	this.address.sendKeys(address);
}


public void setCountry(String country) {
	this.country.sendKeys(country);
}


public void setZipCode(String zipCode) {
	this.zipCode.sendKeys(zipCode);
}


public void setEmail(String email) {
	this.email.sendKeys(email);
}


public void setSex(int selectOptn) {
	this.sex.get(selectOptn).click();
}


public void setLanguage(int language) {
	this.language.get(language).click();
}



}
