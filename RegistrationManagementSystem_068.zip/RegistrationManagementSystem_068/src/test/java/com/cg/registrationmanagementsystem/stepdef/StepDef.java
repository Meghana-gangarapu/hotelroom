package com.cg.registrationmanagementsystem.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.registrationmanagementsystem.bean.RegistrationBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;
	RegistrationBean registration;
	String actualTitle;
	@Before
	public  void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		registration=new RegistrationBean();
		PageFactory.initElements(driver,registration);
		
		
	}
@After
public void finish() throws Exception 
{
	Thread.sleep(3000);
	driver.quit();
}



@Given("^Registration page for validation$")
public void registration_page_for_validation() throws Throwable {
	driver.get("file:///C:/Users/MREDDYPU/Desktop/WebPages/RegistrationForm.html");

}

@When("^Checking title of registration page$")
public void checking_title_of_registration_page() throws Throwable {
	actualTitle=driver.getTitle();

}

@Then("^Check the title with the expected title$")
public void check_the_title_with_the_expected_title() throws Throwable {
	String expected="Welcome to JobsWorld";
	assertEquals(actualTitle, expected);

}

@When("^Enter submit without entering user id$")
public void enter_submit_without_entering_user_id() throws Throwable {

	registration.clickButton();
	
}

@Then("^Get alert 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
public void get_alert_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="User Id should not be empty / length be between 5 to 12";
	assertEquals(expected,actual);

}

@When("^Enter submit without entering password$")
public void enter_submit_without_entering_password() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setUserId("margavi");
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
public void get_alert_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {

	String actual=driver.switchTo().alert().getText();
String expected="Password should not be empty / length be between 7 to 12";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering name$")
public void enter_submit_without_entering_name() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setPassword("margo123");
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'Name should not be empty and must have alphabet characters only'$")
public void get_alert_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {

	String actual=driver.switchTo().alert().getText();
String expected="Name should not be empty and must have alphabet characters only";
	assertEquals(expected,actual);
}

@When("^Enter submit without entering address$")
public void enter_submit_without_entering_address() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setName("Margavi");
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'User address must have alphanumeric characters only'$")
public void get_alert_User_address_must_have_alphanumeric_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="User address must have alphanumeric characters only";
	assertEquals(expected,actual);

}

@When("^Enter submit without selecting country$")
public void enter_submit_without_selecting_country() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setAddress("Hyderabad");
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'Select your country from the list'$")
public void get_alert_Select_your_country_from_the_list() throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="Select your country from the list";
	assertEquals(expected,actual);

}

@When("^Enter submit without entering zip code$")
public void enter_submit_without_entering_zip_code() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setCountry("India");;
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'ZIP code must have numeric characters only'$")
public void get_alert_ZIP_code_must_have_numeric_characters_only() throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="ZIP code must have numeric characters only";
	assertEquals(expected,actual);

}

@When("^Enter submit without entering email$")
public void enter_submit_without_entering_email() throws Throwable {

	driver.switchTo().alert().dismiss();
	registration.setZipCode("123");
	registration.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert 'You have entered an invalid email address!'$")
public void get_alert_You_have_entered_an_invalid_email_address() throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="You have entered an invalid email address!";
	assertEquals(expected,actual);

}

@When("^Enter submit without selecting gender$")
public void enter_submit_without_selecting_gender() throws Throwable {

	driver.switchTo().alert().dismiss();
	registration.setEmail("margavi@gmail.com");
	registration.clickButton();
	Thread.sleep(1000);
}

@Then("^Get alert 'Please Select gender'$")
public void get_alert_Please_Select_gender() throws Throwable {
	String actual=driver.switchTo().alert().getText();
String expected="Please Select gender";
	assertEquals(expected,actual);

}

@When("^All details are entered correctly$")
public void all_details_are_entered_correctly() throws Throwable {
	driver.switchTo().alert().dismiss();
	registration.setSex(1);
	Thread.sleep(500);
	registration.setLanguage(0);
	Thread.sleep(500);
	registration.setLanguage(1);
	registration.clickButton();
	Thread.sleep(1000);

}

@Then("^Get alert 'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
public void get_alert_Your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {


}



}
